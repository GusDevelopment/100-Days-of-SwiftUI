//
//  ContentView.swift
//  GuessTheFlag
//
//  Created by Gustavo Espinoza on 4/4/20.
//  Copyright © 2020 Gustavo Espinoza. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    //This is an array that will reference the flag image file to present later. It containts .shuffled() at the end so that it does not always show the same three flags.
    @State private var countries = ["Estonia", "France", "Germany", "Ireland", "Italy", "Nigeria", "Poland", "Russia", "Spain", "UK", "US" ].shuffled()
    //This is a random number so that we can know what the correct answer flag is.
    @State private var correctAnswer = Int.random(in: 0...2)
    
    //This will let us know when to show the alert later for the user to continue or not continue the game and know the score.
    @State private var showingScore = false
    //This will let the user know if they are correct or wrong.
    @State private var scoreTitle = ""
    
    //This will keep track of the players score.
    @State private var playerScore = 0
    
    //This is to allow us to animate the correct flag
//    @State private var flagRotating = false
//    @State private var animationAmount = 0.0
    
    
    //This body will hold the view of the main game.
    var body: some View {
        ZStack{

            LinearGradient(gradient: Gradient(colors: [.blue, .black]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 30) {

                VStack {
                    Text("Tap the flag of")
                        .foregroundColor(.white)
                        .font(.title)
                    Text(countries[correctAnswer])
                        .foregroundColor(.white)
                        .font(.largeTitle)
                        .fontWeight(.black)
                }
                

                ForEach(0..<3) { number in
                    Button(action: {
                        self.flagTapped(number)
                    }) {
                        Image(self.countries[number])
                            .renderingMode(.original)
                            .clipShape(Capsule())
                            .overlay(Capsule().stroke(Color.black, lineWidth: 1))
                            .shadow(color:.black, radius: 2)
                    }
                }
                
                VStack {
                    Text("Player Score: \(playerScore)")
                        .foregroundColor(.white)
                        .font(.headline)
                }
                //This spacer is moving the game all the way to the top.
                Spacer()
            }
        }
        .alert(isPresented: $showingScore) {
            Alert(title: Text(scoreTitle), message: Text("Your score is \(playerScore)"), dismissButton: .default(Text("Continue")) {
                self.askQuestion()
                })
}

    }
    
    //This function is to check that number is the same as correctAnswer. If so then then the answer is correct. If not then the answer is wrong. It will update the scoceTitle so show the user.
    func flagTapped(_ number: Int) {
       // this if loop is going to change the scoreTitle to correct/wrong. If correct then it will add a point to be displayed later. If wrong, then if this was the first turn then it will remain score at 0 but if already had points it will decrease the score by one.
        if number == correctAnswer {
            scoreTitle = "Correct"
            playerScore += 1
//            flagRotating = true
        } else {
            scoreTitle = "Wrong, that is the flag of \(countries[number])"
            if playerScore == 0 {
                playerScore = 0
            } else {
                playerScore -= 1
            }
        }
        showingScore = true
    }
    
    
    //This function will ask the user if they want to continue, if so it shuffles the array again and creates a new correctAnswer.
    func askQuestion() {
        countries.shuffle()
        correctAnswer = Int.random(in: 0...2)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
