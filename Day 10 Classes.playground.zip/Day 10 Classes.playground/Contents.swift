import UIKit

//there are 5 major differences between structures and classes

class Dog {
    var name: String
    var breed: String
    
    //with classes you have to create an init for the properties
    init(name: String, breed: String) {
        self.name = name
        self.breed = breed
    }
}

let poppy = Dog(name: "Poopy", breed: "Poodle")

// Class inheritance

//This is a child class to the parent Dog class
class Poodle: Dog {
    init(name: String) {
        super.init(name: name, breed: "Poodle")
    }
    
}

//Overriding methods

class Dog2 {
    func makeNoise() {
        print("Woof!")
    }
}

class Poodle2: Dog2 {
    //in order to modify the func in the parent class, you must use the keyword override
    override func makeNoise() {
        print("Yip!")
    }
}

let poppy2 = Poodle2()
poppy2.makeNoise()


//Final classes
// you can make a class in which no other class can inherit or modify its methods by using the word final in front of the class

final class Dog3 {
    var name: String
    var breed: String
    
    init(name:String, breed:String) {
        self.name = name
        self.breed = breed
    }
}


//Copying objects
// third difference between struct and classes is that when you copy and original they are different so when you change things they wont change. As to a class when you change it, it changes the original and copy.

class Singer {
    var name = "Taylor Swift"
}

var singer = Singer()
print(singer.name)

var singerCopy = singer
singerCopy.name = "Justin Bieber"

//because this is a class it changed to Justin Bieber as if it was a struct it wouldve remained Taylor Swift
print(singer.name)

//Deinitializers
// classes can have deinitializers

class Person {
    var name = "john doe"
    
    init() {
        print("\(name) is alive!")
    }
    
    func printGreeting() {
        print("Hello, I'm \(name)")
    }
    
    //this will one every time the person class is finished
    deinit {
        print("\(name) is no more!")
    }

}

for _ in 1...3 {
    let person = Person()
    person.printGreeting()
}


//Mutability
// you dont need the word mutating when changing a constant

class Singer2 {
    var name = "Taylor Swift"
}

let taylor = Singer2()
taylor.name = "Ed Sheeran"
print(taylor.name)


