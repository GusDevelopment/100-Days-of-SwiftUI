import UIKit

var str = "Hello, playground"


// Creating a closure: a function that is assigned to a variable
let driving = {
    print("I'm driving in my car.")
}

driving()

// Accepting parameters into a closure

let driving2 = { (place: String) in
    print("I'm going to \(place) in my car")
}

driving2("London")

// Returning values from a closure

let drivingWithReturn = { (place: String) -> String in
    return "I'm going to \(place) in my car"
}

let message = drivingWithReturn("London")
print(message)

// Closures as parameters

let driving3 = {
    print("I'm driving in my car.")
}

func travel(action: () -> Void) {
    print("I'm getting ready to go.")
    action()
    print("I arrived!")
}

travel(action:driving3)

// Trailing closure syntax; meaning instead of declaring the closure before hand you can declare it afterwards.

func travel2(action: () -> Void) {
    print("I'm getting ready to go.")
    action()
    print("I arrived!")
}

travel(){
    print("I'm driving in my car.")
}
