import UIKit

// handling missing data
// adding a question mark at the end of the type will make it optional or you can set it to nil for not assigning it to anything right now

var age: Int? = nil


// Unwrapping optionals

var name: String? = nil

// cannot just check to see the count of a string this way. an optional needs to be unwrapped first.
// need to use the syntax if let

if let unwrapped = name {
    print("\(unwrapped.count) letters")
} else {
    print("Missing name.")
}

// Unwrapping with guard

func greet(_ name: String?) {
    guard let unwrapped = name else {
        print("You didnt provide a name!")
        return
    }
    
    print("Hello, \(unwrapped)!")
}

//let hello = greet("Gus")
//print(hello)

// Force unwrapping

let str = "5"
let num = Int(str)!


// Implicitly unwrapped optionals
// will act like a variable is unwrapped already, all you do is add an exclamation mark after the type, however, when used if its nil; it will cause yur code to crash

let age2: Int! = nil

//Nil coalescing

func username(for id: Int) -> String? {
    if id == 1 {
        return "taylor swift"
    } else {
        return nil
    }
}

// because ID 15 wont be recognized it will return nil but if using ?? " " you can return a default value if nil
let user = username(for: 15) ?? "Anonymous"

//Optional Chaining

let names = ["John", "Paul", "George", "Ringo"]

// the ? after first will check to see if there is a value there, if not it will return nil before it tries to uppercase
let beatle = names.first?.uppercased()

//Optional try

enum PasswordError: Error {
    case obvious
}

func checkPassword(_ password: String) throws -> Bool {
    if password == "password" {
        throw PasswordError.obvious
    }
    
    return true
}

do {
    try checkPassword("password")
    print("That password is good!")
} catch {
    print("You cant use that password.")
}


if let result = try? checkPassword("password") {
    print("Result was \(result)")
} else {
    print("D'oh.")
}


// Failable initializers

struct Person {
    var id: String
    
    
    // this is a failable initializer, it might run or might return nil if it doesnt meet the requirements
    init?(id: String) {
        if id.count == 9 {
            self.id = id
        } else {
            return nil
        }
    }
}

//Typecasting

class Animal {}
class Fish: Animal {}
class Dog: Animal {
    func makeNoise() {
        print("Woof!")
    }
}

let pets = [Fish(), Dog(), Fish(), Dog()]

// the keyword as? will check to see if the object is of the type and return il if not or run if it matches
for pet in pets {
    if let dog = pet as? Dog {
        dog.makeNoise()
    }
}

