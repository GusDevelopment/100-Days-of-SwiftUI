import UIKit

var str = "Hello, playground"



//For Loops

let count = 1...10

for number in count {
    print("Number is \(number)")
}

let albums = ["Red", "1989", "Reputation"]

for album in albums {
    print("\(album) is in Apple Music")
}

//While Loops

var number = 1

while number <= 20 {
    print(number)
    number += 1
}

print("Ready or not, here I come!")

//Repeat Loops (not common)

var number2 = 1

repeat {
    print(number2)
    number2 += 1
} while number2 <= 20

print("Ready or not, here I come!")

//Exiting Loops

var countDown = 10

while countDown >= 10 {
    print(countDown)
    
    if countDown == 4 {
        print("I'm bored. lets go now!")
        //breka is the keyword to exit a loop
        break
    }
    countDown -= 1
}

print("Blast off!")


//Infinite loops

var counter = 0

while true {
    print(" ")
    counter += 1
    
    //condition to make sure loop stops eventually
    if counter == 273{
        break
    }
}


