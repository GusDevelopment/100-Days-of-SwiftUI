import UIKit


//Writing functions
func printHelp() {
    let message = """
Welcome to MyApp!

Run this app inside a directory of images and
MyApp will resize them all into thumbnails.
"""
    print(message)
}

printHelp()

//Acceptin parameters

func square(number: Int) {
    print(number * number)
}

square(number: 3)

//Returning Values

func square2(number: Int) -> Int {
    return number * number
}

let result = square2(number: 4)
print(result)


//Parameter labels

func sayHello(to name: String) {
    print("Hello, \(name)!")
}

sayHello(to: "Gus")

//Omitting paramters

func greet(_ person: String) {
    print("Hello, \(person)!")
}

greet("Jose")

//Default parameters

func greet2(_ person: String, nicely:Bool = true) {
    if nicely == true{
        print("Hello, \(person)!")
    } else {
        print("Oh no, its \(person) again...")
    }
}

greet2("Madrid")
greet2("Madrid", nicely: false)

//Variadic function

func square(numbers: Int...){
    for number in numbers {
        print("\(number) square is \(number * number)")
    }
}

square(numbers: 1,2,3,4,5)

//Writing throwing functions

//enum to show possible error codes
enum PasswordError: Error {
    case obvious
}

//function to check password
func checkPassword(_ password: String) throws -> Bool {
    if password == "password" {
        throw PasswordError.obvious
    }
    return true
}

//in order to run functions that can have an error you must use do, try, and catch
do {
    try checkPassword("password")
    print("That password is good!")
}catch {
    print("You cant use that password!")
}

//Inout paramters
//means you can change the variable type inside the function and it would reflect outside the function
func doubleInPlace(number: inout Int) {
    number *= 2
}

var myNum = 10
doubleInPlace(number: &myNum)

